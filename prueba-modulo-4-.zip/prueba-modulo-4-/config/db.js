// config/db.js
const { Pool } = require('pg');
const dotenv = require('dotenv');

dotenv.config();

const pool = new Pool({
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  host: process.env.DB_HOST,
  database: process.env.DB_DATABASE,
  port: process.env.DB_PORT,
});

async function testConnection() {
  try {
    const client = await pool.connect();
    console.log('Successfully connected to the database!');
    client.release();
    return { success: true, message: 'Database connection successful' };
  } catch (error) {
    console.error('Error connecting to the database:', error.message);
    return { success: false, message: error.message };
  }
}

module.exports = { pool, testConnection };
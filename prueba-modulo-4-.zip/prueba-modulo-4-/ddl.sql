--CREATE DATABASE expertsoft_financial;
--\c expertsoft_financial;


CREATE TABLE type_identification (
    id_type_identification SERIAL PRIMARY KEY,
    type_identification VARCHAR(150) NOT NULL UNIQUE
);


CREATE TABLE users (
    id_client SERIAL PRIMARY KEY,
    name_client VARCHAR(255) NOT NULL,
    identification VARCHAR(100) NOT NULL UNIQUE,
    id_type_identification INT NOT NULL,
    address VARCHAR(255) NOT NULL,
    phone VARCHAR(255) NOT NULL,
    email VARCHAR(120) NOT NULL,
    FOREIGN KEY (id_type_identification) REFERENCES type_identification(id_type_identification) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE transaction_status (
    id_status SERIAL PRIMARY KEY,
    status VARCHAR(150) NOT NULL UNIQUE
);


CREATE TABLE type_transaction (
    id_type_transaction SERIAL PRIMARY KEY,
    type_transaction VARCHAR(150) NOT NULL UNIQUE
);


CREATE TABLE financial_institution (
    id_financial_institution SERIAL PRIMARY KEY,
    financial_institution VARCHAR(255) NOT NULL UNIQUE
);


CREATE TABLE type_currency (
    id_type_currency SERIAL PRIMARY KEY,
    type_of_currency VARCHAR(150) NOT NULL UNIQUE
);


CREATE TABLE transaction (
    id_transaction VARCHAR(30) PRIMARY KEY,
    date_transaction TIMESTAMP NOT NULL,
    transaction_amount FLOAT NOT NULL,
    id_transaction_status INT NOT NULL,
    id_type_transaction INT NOT NULL,
    id_type_currency INT NOT NULL,
    FOREIGN KEY (id_transaction_status) REFERENCES transaction_status(id_status) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_type_transaction) REFERENCES type_transaction(id_type_transaction) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_type_currency) REFERENCES type_currency(id_type_currency) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE billing (
    id_billing VARCHAR(30) PRIMARY KEY,
    date_billing VARCHAR(20) NOT NULL,
    id_client INT NOT NULL,
    id_transaction VARCHAR(30) NOT NULL,
    id_financial_institution INT NOT NULL,
    id_type_currency INT NOT NULL,
    invoiced_amount FLOAT NOT NULL,
    paid_amount FLOAT NOT NULL,
    FOREIGN KEY (id_client) REFERENCES users(id_client) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_transaction) REFERENCES transaction(id_transaction) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_financial_institution) REFERENCES financial_institution(id_financial_institution) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (id_type_currency) REFERENCES type_currency(id_type_currency) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO type_identification (type_identification) VALUES ('Cédula');
INSERT INTO transaction_status (status) VALUES ('Pendiente'), ('Fallida'), ('Completada');
INSERT INTO type_transaction (type_transaction) VALUES ('Pago de Factura');
INSERT INTO financial_institution (financial_institution) VALUES ('Nequi'), ('Daviplata');
INSERT INTO type_currency (type_of_currency) VALUES ('COP');
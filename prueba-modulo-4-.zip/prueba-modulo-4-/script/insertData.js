// script/insertData.js
const fs = require('fs');
const { parse } = require('csv-parse');
const { pool, testConnection } = require('../config/db'); // Import both pool and testConnection

async function insertData() {
  try {
    // Verificar conexión a la base de datos
    const connectionResult = await testConnection(); // Call testConnection directly
    if (!connectionResult.success) {
      throw new Error('Failed to connect to the database');
    }

    // Leer el archivo CSV
    const records = [];
    fs.createReadStream('data/transactions.csv')
      .pipe(parse({ columns: true, trim: true }))
      .on('data', (record) => records.push(record))
      .on('end', async () => {
        try {
          // Iniciar transacción
          const client = await pool.connect();

          try {
            await client.query('BEGIN');

            // Insertar usuarios (evitar duplicados por identificación)
            const uniqueUsers = {};
            records.forEach(record => {
              uniqueUsers[record['Número de Identificación']] = {
                name_client: record['Nombre del Cliente'],
                identification: record['Número de Identificación'],
                address: record['Dirección'],
                phone: record['Teléfono'],
                email: record['Correo Electrónico']
              };
            });

            const userValues = Object.values(uniqueUsers).map(user => 
              `(${client.escapeLiteral(user.name_client)}, ${client.escapeLiteral(user.identification)}, 1, ${client.escapeLiteral(user.address)}, ${client.escapeLiteral(user.phone)}, ${client.escapeLiteral(user.email)})`
            ).join(',');

            if (userValues) {
              await client.query(`
                INSERT INTO users (name_client, identification, id_type_identification, address, phone, email)
                VALUES ${userValues}
                ON CONFLICT (identification) DO NOTHING
              `);
              console.log('Users inserted successfully');
            }

            // Obtener mapeo de identificaciones a id_client
            const userResult = await client.query('SELECT id_client, identification FROM users');
            const userMap = new Map(userResult.rows.map(row => [row.identification, row.id_client]));

            // Insertar transacciones
            const transactionValues = records.map(record => {
              const statusMap = { 'Pendiente': 1, 'Fallida': 2, 'Completada': 3 };
              return `(${client.escapeLiteral(record['ID de la Transacción'])}, ${client.escapeLiteral(record['Fecha y Hora de la Transacción'])}, ${parseFloat(record['Monto de la Transacción'])}, ${statusMap[record['Estado de la Transacción']]}, 1, 1)`;
            }).join(',');

            await client.query(`
              INSERT INTO transaction (id_transaction, date_transaction, transaction_amount, id_transaction_status, id_type_transaction, id_type_currency)
              VALUES ${transactionValues}
            `);
            console.log('Transactions inserted successfully');

            // Insertar facturas
            const billingValues = records.map(record => {
              const financialInstitutionMap = { 'Nequi': 1, 'Daviplata': 2 };
              return `(${client.escapeLiteral(record['Número de Factura'])}, TO_DATE(${client.escapeLiteral(record['Periodo de Facturación'])}, 'YYYY-MM'), ${userMap.get(record['Número de Identificación'])}, ${client.escapeLiteral(record['ID de la Transacción'])}, ${financialInstitutionMap[record['Plataforma Utilizada']]}, 1, ${parseFloat(record['Monto Facturado'])}, ${parseFloat(record['Monto Pagado'])})`;
            }).join(',');

            await client.query(`
              INSERT INTO billing (id_billing, date_billing, id_client, id_transaction, id_financial_institution, id_type_currency, invoiced_amount, paid_amount)
              VALUES ${billingValues}
            `);
            console.log('Billing records inserted successfully');

            await client.query('COMMIT');
            console.log('All data inserted successfully');
          } catch (error) {
            await client.query('ROLLBACK');
            throw error;
          } finally {
            client.release();
          }
        } catch (error) {
          console.error('Error inserting data:', error.message);
        } finally {
          await pool.end();
        }
      })
      .on('error', (error) => {
        console.error('Error reading CSV:', error.message);
      });
  } catch (error) {
    console.error('Error in insertData:', error.message);
  }
}

insertData().catch(error => {
  console.error('Script failed:', error);
  process.exit(1);
});
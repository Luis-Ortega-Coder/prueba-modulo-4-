-- PASO 1: Insertar un usuario para que id_client=1 exista
-- PASO 1: Insertar transacción (antes de la factura)
INSERT INTO transaction (
    id_transaction, 
    date_transaction, 
    transaction_amount, 
    id_transaction_status, 
    id_type_transaction, 
    id_type_currency
) VALUES (
    'TXN9999', 
    '2024-07-01 10:00:00', 
    100000.00, 
    1,  -- Pendiente (ID de transaction_status)
    1,  -- Pago de Factura (ID de type_transaction)
    1   -- COP (ID de type_currency)
);

-- PASO 2: Ahora insertar la factura (con id_transaction existente)
INSERT INTO billing (
    id_billing, 
    date_billing, 
    id_client, 
    id_transaction, 
    id_financial_institution, 
    id_type_currency, 
    invoiced_amount, 
    paid_amount
) VALUES (
    'FAC9999', 
    '2024-07', 
    1,  -- ID del usuario recién insertado
    'TXN9999',  -- ID de transacción existente
    1,  -- Nequi (ID de financial_institution)
    1,  -- COP (ID de type_currency)
    100000.00, 
    0.00
);
-- READ (SELECT ALL)
SELECT 
    id_billing,
    date_billing,
    id_client,
    id_transaction,
    id_financial_institution,
    invoiced_amount,
    paid_amount
FROM billing;

-- READ (SELECT BY ID)
SELECT 
    id_billing,
    date_billing,
    id_client,
    id_transaction,
    id_financial_institution,
    invoiced_amount,
    paid_amount
FROM billing
WHERE id_billing = 'FAC9999';

-- UPDATE
UPDATE billing
SET 
    paid_amount = 50000.00
WHERE id_billing = 'FAC9999';

-- DELETE
DELETE FROM billing
WHERE id_billing = 'FAC9999';

--query advanced
-- 1. Total pagado por cada cliente
SELECT 
    u.name_client AS customer_name,
    SUM(b.paid_amount) AS total_paid
FROM 
    users u
JOIN 
    billing b ON u.id_client = b.id_client
GROUP BY 
    u.id_client, u.name_client;

-- 2. Facturas pendientes con información de cliente y transacción
SELECT 
    b.id_billing AS invoice_id,
    u.name_client AS customer_name,
    t.id_transaction AS transaction_id,
    t.date_transaction AS transaction_date
FROM 
    billing b
JOIN 
    users u ON b.id_client = u.id_client
JOIN 
    transaction t ON b.id_transaction = t.id_transaction
JOIN 
    transaction_status ts ON t.id_transaction_status = ts.id_status
WHERE 
    ts.status = 'Pendiente';

-- 3. Listado de transacciones por plataforma (ejemplo para Nequi)
SELECT 
    t.id_transaction AS transaction_id,
    u.name_client AS customer_name,
    b.id_billing AS invoice_id,
    t.transaction_amount AS amount,
    t.date_transaction AS transaction_date
FROM 
    transaction t
JOIN 
    billing b ON t.id_transaction = b.id_transaction
JOIN 
    users u ON b.id_client = u.id_client
JOIN 
    financial_institution fi ON b.id_financial_institution = fi.id_financial_institution
WHERE 
    fi.financial_institution = 'Nequi';